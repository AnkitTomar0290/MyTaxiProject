package com.mytaxi.android_demo;

import android.support.test.espresso.NoMatchingViewException;
import android.support.test.espresso.ViewInteraction;
import android.support.test.espresso.action.ViewActions;
import android.support.test.espresso.matcher.RootMatchers;
import android.support.test.espresso.matcher.ViewMatchers;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.util.Log;
import com.mytaxi.android_demo.activities.MainActivity;
import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.Espresso.pressBack;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.assertion.ViewAssertions.doesNotExist;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isCompletelyDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withClassName;
import static android.support.test.espresso.matcher.ViewMatchers.withEffectiveVisibility;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static android.support.v4.content.ContextCompat.startActivity;
import static org.hamcrest.CoreMatchers.endsWith;
import static org.hamcrest.core.AllOf.allOf;


@RunWith(AndroidJUnit4.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestMyTaxiApp {
    @Rule
    public ActivityTestRule<MainActivity> mActivityRule =
            new ActivityTestRule<>(MainActivity.class);
    // Variable declaration
    private String username = null;
    private String password = null;
    private static String flag = "null";

    @Before
    public void setUp() throws Exception {
         flag = "false";
    }

    @Test
    public void test1__Invalid_Username() throws InterruptedException {

        // Parameter initialized with Invalid Username
        username = "username";
        password = "venture";

        onView(withId(R.id.edt_username)).perform(ViewActions.typeText(username));
        onView(withId(R.id.edt_password)).perform(ViewActions.typeText(password));
        onView(withId(R.id.btn_login)).perform(click());

        Thread.sleep(1500);

        // Asserting invalid login using View Matcher withText
        onView(withText("mytaxi demo")).check(doesNotExist());
    }

    @Test
    public void test2_Invalid_Password() throws InterruptedException {

        // Parameter initialized with Invalid Password
        username = "crazydog335";
        password = "password";

        onView(withId(R.id.edt_username)).perform(ViewActions.typeText(username));
        onView(withId(R.id.edt_password)).perform(ViewActions.typeText(password));
        onView(withId(R.id.btn_login)).perform(click());
        Thread.sleep(1500);

        // Asserting invalid login using View Matcher withId
        onView(withId(R.id.toolbar)).check(doesNotExist());
    }

    @Test
    public void test3_Valid_LoginId(){

        flag = "true";
        username = "crazydog335";
        password = "venture";

        try {
            onView(withId(R.id.edt_username)).perform(ViewActions.typeText(username));
            onView(withId(R.id.edt_password)).perform(ViewActions.typeText(password));
            onView(withId(R.id.btn_login)).perform(click());
            Thread.sleep(1500);
            onView(withId(R.id.toolbar)).check(matches(isDisplayed()));
            String var = "sa";
            onView(withId(R.id.textSearch)).perform(ViewActions.typeText(var));
            Thread.sleep(1500);
            onView(allOf(withId(R.id.searchContainer),
                    withEffectiveVisibility(ViewMatchers.Visibility.VISIBLE)))
                    .check(matches(isCompletelyDisplayed()));

            Thread.sleep(1500);

            
            onView(withText("Sarah Scott"))
                    .inRoot(RootMatchers.isPlatformPopup())
                    .perform(click());

            Thread.sleep(1000);
            onView(withId(R.id.imageViewDriverAvatar)).check(matches(isDisplayed()));
            onView(withId(R.id.fab)).perform(click());

        }catch (Exception msg) {
            Log.e("Exception : ", msg.getMessage());
        }
    }

    @After
    public void tearDown() throws Exception {

        // Logout on successful login

        try {
            if (flag.equals("true")) {
                onView(withClassName(endsWith("ImageButton"))).check(matches(isDisplayed())).perform(click());
                Thread.sleep(1500);
                ViewInteraction status = onView(withClassName(endsWith("ImageButton"))).check(matches(isDisplayed()));
                Log.d("My Tag", status + "");
                Thread.sleep(1500);
                onView((withId(R.id.design_menu_item_text))).check(matches(isDisplayed())).perform(click());
            }
        } catch (NoMatchingViewException msg) {
            Log.e("NoMatchingViewException : ", msg.getMessage());
        }
    }
}